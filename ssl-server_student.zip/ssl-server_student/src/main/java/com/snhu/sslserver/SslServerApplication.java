package com.snhu.sslserver;

import java.security.MessageDigest;

import org.apache.catalina.Context;
import org.apache.catalina.connector.Connector;
import org.apache.tomcat.util.descriptor.web.SecurityCollection;
import org.apache.tomcat.util.descriptor.web.SecurityConstraint;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.embedded.tomcat.TomcatServletWebServerFactory;
import org.springframework.boot.web.servlet.server.ServletWebServerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}
	
	@Bean
	public ServletWebServerFactory servletContainer() {
	    TomcatServletWebServerFactory tomcat = new TomcatServletWebServerFactory() {
	        @Override
	        protected void postProcessContext(Context context) {
	            SecurityConstraint securityConstraint = new SecurityConstraint();
	            securityConstraint.setUserConstraint("CONFIDENTIAL");
	            SecurityCollection collection = new SecurityCollection();
	            collection.addPattern("/*");
	            securityConstraint.addCollection(collection);
	            context.addConstraint(securityConstraint);
	        }
	    };
	    tomcat.addAdditionalTomcatConnectors(redirectConnector());
	    return tomcat;
	}

	private Connector redirectConnector() {
	  Connector connector = new Connector("org.apache.coyote.http11.Http11NioProtocol");
	  connector.setScheme("http");
	  connector.setPort(8080);
	  connector.setSecure(false);
	  connector.setRedirectPort(8443);
	  
	  return connector;
	}
}

@RestController
class ServerController{   
    @RequestMapping("/hash")
    public String myHash() throws Exception{
    	
    	MessageDigest md = MessageDigest.getInstance("SHA-256");
    	byte[] digest = md.digest();
    	
    	StringBuffer hexString = new StringBuffer();
    	
    	for (int i = 0;i < digest.length; i++) {
    		hexString.append(Integer.toHexString(0xFF & digest[i]));
    	}
    	
    	String data = "Tristan Maloy";
       
        return "<p>data:" + data + "\n\nSHA-256 : CheckSum Value:" + hexString.toString();
    }
}
//FIXME: Add route to enable check sum return of static data example:  String data = "Hello World Check Sum!";